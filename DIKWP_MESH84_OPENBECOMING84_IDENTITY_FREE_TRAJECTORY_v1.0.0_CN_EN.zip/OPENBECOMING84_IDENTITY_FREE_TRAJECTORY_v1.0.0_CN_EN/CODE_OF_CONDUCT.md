# Code of Conduct

Do not use the project to label named persons as nonhuman, zombies, evil, or disposable. Critique bounded processes with evidence.
