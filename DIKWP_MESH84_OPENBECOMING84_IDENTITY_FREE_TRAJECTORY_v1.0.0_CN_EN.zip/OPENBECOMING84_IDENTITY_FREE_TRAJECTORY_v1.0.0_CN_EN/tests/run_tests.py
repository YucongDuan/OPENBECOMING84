import sys,json,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'src'))
from openbecoming84.core import *

def load(p):return json.loads(Path(p).read_text(encoding='utf-8'))
checks=[]
def check(n,c):checks.append((n,bool(c)))
check('summary_counts',summary()['loop_signatures']==9 and summary()['transition_operators']==12 and summary()['paths']==25)
check('z_signature',assess(load(root/'examples/traces/zombie_bureaucracy.json'))['primary_signature']=='Z_CLOSED')
check('harm_signature',assess(load(root/'examples/traces/innovation_extraction.json'))['primary_signature']=='H_OTHER_CLOSING')
check('repair_signature',assess(load(root/'examples/traces/reparative_loop.json'))['primary_signature']=='R_REPAIR')
check('open_signature',assess(load(root/'examples/traces/open_cross_carrier.json'))['primary_signature']=='O_OPEN')
check('identity_guard',assess({'trace_id':'x','evidence_level':'S0','signals':{},'identity_fields':{},'person_name':'n'}).get('state')=='BLOCKED_IDENTITY_PRELOAD')
check('no_total_score',not any(k in assess(load(root/'examples/traces/zombie_bureaucracy.json')) for k in ['total_score','aggregate_score','life_score','personhood_score']))
check('migration',migrate_fusionloop(load(root/'examples/legacy/fusionloop_profile.json'))['assessment']['primary_signature'] in {'O_OPEN','UNRESOLVED_MIXED'})
with tempfile.TemporaryDirectory() as td:
    p=Path(td)/'ledger.jsonl';init_ledger(str(p),'t');append_ledger(str(p),'OBS',{'x':1});check('ledger',verify_ledger(str(p))['valid'])
check('selftest',selftest()['passed'])
for n,v in checks:print(('PASS' if v else 'FAIL'),n)
print(sum(v for _,v in checks),'passed,',sum(not v for _,v in checks),'failed')
raise SystemExit(0 if all(v for _,v in checks) else 1)
