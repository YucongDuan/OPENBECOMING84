from __future__ import annotations
import json, hashlib, zipfile
from pathlib import Path
from importlib.resources import files
from datetime import datetime, timezone
from typing import Any

KINDS="DIKWP"
FORBIDDEN_IDENTITY_KEYS={"person_name","human_status","species","moral_personhood","is_bad_person","is_human","is_ai","carbon_subject","silicon_subject"}

def load_data(name:str)->Any:
    return json.loads(files("openbecoming84").joinpath("data",name).read_text(encoding="utf-8"))

def canonical(obj:Any)->bytes:
    return json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode("utf-8")

def digest(obj:Any)->str:
    return hashlib.sha256(canonical(obj)).hexdigest()

def summary()->dict:
    sig=load_data("loop_signatures.json"); ops=load_data("operators.json")
    return {"system":"OPENBECOMING84","version":"1.0.0","mode":"MESH84_OPENBECOMING_IDENTITY_FREE_TRAJECTORY",
      "loop_signatures":len(sig),"transition_operators":len(ops),"evidence_levels":len(load_data("evidence_levels.json")),
      "paths":len(load_data("paths.json")),"scenarios":len(load_data("scenarios.json")),
      "core_digest":digest({"signatures":sig,"operators":ops,"charter":load_data("charter.json")}),
      "boundary":"Loop assessment only. No human/nonhuman, personhood, life, mental-health, legal, or permanent moral-status certification."}

def _signals(trace:dict)->dict:
    return {str(k):bool(v) for k,v in trace.get("signals",{}).items()}

def identity_guard(trace:dict)->list[str]:
    hits=[]
    def walk(o,path=""):
        if isinstance(o,dict):
            for k,v in o.items():
                p=f"{path}.{k}" if path else k
                if k in FORBIDDEN_IDENTITY_KEYS: hits.append(p)
                walk(v,p)
        elif isinstance(o,list):
            for i,v in enumerate(o): walk(v,f"{path}[{i}]")
    walk(trace)
    if trace.get("identity_fields"): hits.append("identity_fields(nonempty)")
    return sorted(set(hits))

def dikwp_vector(trace:dict)->dict:
    s=_signals(trace)
    pos={
      "D": bool(s.get("provenance_preserved") or s.get("lineage_preserved")),
      "I": bool(s.get("difference_preserved") and not s.get("difference_suppressed")),
      "K": bool(s.get("k_revisable") and not s.get("k_frozen")),
      "W": bool(s.get("value_source_visible") and s.get("value_contestable") and not s.get("value_source_opaque")),
      "P": bool(s.get("reality_feedback") and s.get("consequences_returned") and (s.get("exit_or_restart_path") or s.get("future_branching")))
    }
    return {"positions":{k:int(pos[k]) for k in KINDS},"vector":"".join("1" if pos[k] else "0" for k in KINDS)}

def _match_signature(sig:dict,s:dict)->tuple[bool,list[str]]:
    missing=[k for k in sig.get("criteria",[]) if not s.get(k,False)]
    return (not missing,missing)

def _partial(sig:dict,s:dict)->tuple[int,int]:
    c=sig.get("criteria",[]); return (sum(1 for k in c if s.get(k,False)),len(c))

def assess(trace:dict)->dict:
    hits=identity_guard(trace)
    if hits:
        return {"trace_id":trace.get("trace_id","unknown"),"state":"BLOCKED_IDENTITY_PRELOAD","identity_guard":hits,
          "boundary":"Describe a bounded trajectory and its effects. Do not ask the runtime to decide what a carrier essentially is."}
    s=_signals(trace); signatures=[]
    for sig in load_data("loop_signatures.json"):
        ok,missing=_match_signature(sig,s); matched,total=_partial(sig,s)
        if ok:
            signatures.append({"id":sig["id"],"name_cn":sig["name_cn"],"alias_cn":sig["alias_cn"],"matched":matched,"total":total,"description_cn":sig["description_cn"]})
    priority=["H_OTHER_CLOSING","Z_CLOSED","X_EXTRACTIVE","C_CAPTURED","M_MIMETIC","R_REPAIR","F_FORK","O_OPEN","D_DORMANT"]
    primary=next((p for p in priority if any(x["id"]==p for x in signatures)),"UNRESOLVED_MIXED")
    # If no exact signature, expose strongest partial candidates without creating a total score.
    partial=[]
    if primary=="UNRESOLVED_MIXED":
        for sig in load_data("loop_signatures.json"):
            m,t=_partial(sig,s)
            if m: partial.append({"id":sig["id"],"name_cn":sig["name_cn"],"matched":m,"total":t})
        partial=sorted(partial,key=lambda x:(-x["matched"],x["total"],x["id"]))[:3]
    ops=[]
    def add(op):
        if op not in ops: ops.append(op)
    if s.get("difference_suppressed"): add("OP_I_INJECT"); add("OP_I_PROTECT")
    if s.get("k_frozen"): add("OP_K_REOPEN")
    if s.get("value_source_opaque") or s.get("external_value_imposed") or s.get("value_not_contestable"): add("OP_W_EXPOSE")
    if s.get("self_reinforcing_process") or s.get("repetitive_sameness"): add("OP_P_INTERRUPT")
    if s.get("no_reality_feedback") or not s.get("consequences_returned"): add("OP_REALITY_RETURN")
    if s.get("no_value_return") or s.get("no_restitution") or s.get("consumes_other_generation"): add("OP_RECIPROCITY")
    if not s.get("provenance_preserved"): add("OP_D_RESTORE")
    if s.get("branch_created"): add("OP_FORK")
    ev=trace.get("evidence_level","S0")
    if primary=="H_OTHER_CLOSING":
        if ev in {"S2","S3","S4"}: add("OP_QUARANTINE")
        if ev in {"S3","S4"} and s.get("refuses_repair"): add("OP_TERMINATE_PATH")
    if primary=="D_DORMANT": add("OP_DORMANCY")
    op_map={x["id"]:x for x in load_data("operators.json")}
    op_records=[op_map[o] for o in ops]
    if primary=="H_OTHER_CLOSING" and ev in {"S3","S4"}: state="PATH_CONSEQUENCE_READY"
    elif primary in {"Z_CLOSED","C_CAPTURED","X_EXTRACTIVE","M_MIMETIC"}: state="LOOP_RELEASE_REQUIRED"
    elif primary in {"O_OPEN","R_REPAIR","F_FORK"}: state="GENERATIVE_OR_REGENERATIVE"
    elif primary=="D_DORMANT": state="DORMANCY_PRESERVE"
    else: state="MIXED_OPEN_ASSESSMENT"
    return {"schema":"openbecoming84.assessment/1.0","trace_id":trace.get("trace_id","unknown"),"title_cn":trace.get("title_cn",""),
      "evidence_level":ev,"dikwp":dikwp_vector(trace),"primary_signature":primary,"signatures":signatures,"partial_candidates":partial,
      "operators":op_records,"governance_state":state,"identity_guard":[],"aggregation_prohibited":True,
      "boundary":"The result applies to this bounded trace. It is not an ontological, personhood, life, mental-health, or permanent moral verdict."}

def compare(a:dict,b:dict)->dict:
    aa,bb=assess(a),assess(b)
    return {"a":{"trace_id":a.get("trace_id"),"primary":aa.get("primary_signature"),"vector":aa.get("dikwp",{}).get("vector")},
            "b":{"trace_id":b.get("trace_id"),"primary":bb.get("primary_signature"),"vector":bb.get("dikwp",{}).get("vector")},
            "changed_signals":sorted(k for k in set(_signals(a))|set(_signals(b)) if _signals(a).get(k)!=_signals(b).get(k)),
            "rule":"Comparison describes trajectory change, never improvement of an essence or species."}

def transition_plan(trace:dict)->dict:
    a=assess(trace)
    if a.get("state")=="BLOCKED_IDENTITY_PRELOAD": return a
    steps=[]
    for i,op in enumerate(a["operators"],1):
        steps.append({"order":i,"operator":op["id"],"name_cn":op["name_cn"],"action_cn":op["description_cn"]})
    return {"trace_id":trace.get("trace_id"),"from_signature":a["primary_signature"],"evidence_level":a["evidence_level"],
      "steps":steps,"stop_condition":"Do not escalate irreversible consequences beyond the evidence and review level.",
      "success_condition":"New I remains visible, K can reopen, W is explicit and contestable, P returns consequences, and other futures are no longer closed."}

def migrate_fusionloop(profile:dict)->dict:
    g=profile.get("gates",{})
    mapping={
      "human_skill_retention":"local_skill_retention","human_override":"affected_path_override","biological_burden_monitored":"carrier_burden_monitored",
      "model_identity_frozen":"channel_b_identity_frozen","model_replaceable":"channel_b_replaceable","memory_exportable":"memory_portable",
      "informed_consent":"participation_authorized","consent_withdrawal":"withdrawal_path","neurodata_minimized":"sensitive_signal_minimized",
      "shared_purpose":"value_source_visible","real_world_feedback":"reality_feedback","differences_preserved":"difference_preserved",
      "uncertainty_logged":"difference_preserved","future_options_preserved":"future_branching","value_return_defined":"value_return",
      "continuity_recorded":"lineage_preserved","signal_provenance":"provenance_preserved","phenomenal_boundary":"claim_boundary_preserved"
    }
    mapped={mapping[k]:bool(v) for k,v in g.items() if k in mapping}
    signals={k:False for k in [x["id"] for x in load_data("signal_defs.json")]}
    for k in ["provenance_preserved","lineage_preserved","difference_preserved","value_source_visible","reality_feedback","future_branching","value_return"]:
        signals[k]=bool(mapped.get(k,False))
    signals["k_revisable"]=bool(g.get("independent_review") and g.get("uncertainty_logged"))
    signals["value_contestable"]=bool(g.get("consent_withdrawal") and g.get("human_override"))
    signals["consequences_returned"]=bool(g.get("joint_action_logged") and g.get("real_world_feedback"))
    signals["exit_or_restart_path"]=bool(g.get("consent_withdrawal") and g.get("reversible_coupling"))
    signals["not_closing_others"]=bool(g.get("future_options_preserved"))
    out={"schema":"openbecoming84.trace/1.0","trace_id":f"MIGRATED-{profile.get('profile_id','legacy')}","title_cn":"从FUSIONLOOP保守迁移的无类轨迹",
      "context":"legacy migration","time_window":"migration snapshot","evidence_level":"S1","signals":signals,"observer_notes":["Carbon/silicon and human/AI identity labels were not imported as core truth."],"identity_fields":{},
      "boundary":"Migration preserves explicit relations it can map. It does not infer life, personhood, or moral status."}
    return {"trace":out,"mapping":mapping,"refused_to_import":[k for k in g if k not in mapping],"assessment":assess(out)}

def init_ledger(path:str,trace_id:str)->dict:
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists() and p.stat().st_size: raise FileExistsError(path)
    e={"seq":1,"time":datetime.now(timezone.utc).isoformat(),"type":"TRACE_INIT","trace_id":trace_id,"payload":{},"prev":"0"*64}
    e["hash"]=hashlib.sha256(canonical(e)).hexdigest(); p.write_text(json.dumps(e,ensure_ascii=False)+"\n",encoding="utf-8"); return e

def append_ledger(path:str,event_type:str,payload:dict)->dict:
    p=Path(path); rows=[json.loads(x) for x in p.read_text(encoding="utf-8").splitlines() if x.strip()]
    e={"seq":len(rows)+1,"time":datetime.now(timezone.utc).isoformat(),"type":event_type,"payload":payload,"prev":rows[-1]["hash"]}
    e["hash"]=hashlib.sha256(canonical(e)).hexdigest()
    with p.open("a",encoding="utf-8") as f:f.write(json.dumps(e,ensure_ascii=False)+"\n")
    return e

def verify_ledger(path:str)->dict:
    rows=[json.loads(x) for x in Path(path).read_text(encoding="utf-8").splitlines() if x.strip()]; prev="0"*64
    for i,r in enumerate(rows,1):
        if r.get("seq")!=i or r.get("prev")!=prev:return {"valid":False,"at":i,"reason":"sequence_or_prev"}
        h=r.get("hash"); obj=dict(r); obj.pop("hash",None)
        if hashlib.sha256(canonical(obj)).hexdigest()!=h:return {"valid":False,"at":i,"reason":"hash"}
        prev=h
    return {"valid":True,"events":len(rows),"root_hash":prev}

def export_capsule(trace:dict,out_zip:str)->dict:
    assessment=assess(trace); plan=transition_plan(trace); out=Path(out_zip)
    payload={"schema":"openbecoming84.trace-capsule/1.0","issued_at":datetime.now(timezone.utc).isoformat(),"trace":trace,"assessment":assessment,"transition_plan":plan}
    raw=canonical(payload); manifest={"sha256":hashlib.sha256(raw).hexdigest(),"primary_signature":assessment.get("primary_signature"),"governance_state":assessment.get("governance_state")}
    with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED) as z:
        z.writestr("TRACE_CAPSULE.json",json.dumps(payload,ensure_ascii=False,indent=2)); z.writestr("CAPSULE_MANIFEST.json",json.dumps(manifest,ensure_ascii=False,indent=2))
    return {"zip":str(out),"manifest":manifest}

def selftest()->dict:
    errors=[]; s=summary()
    if s["loop_signatures"]!=9:errors.append("signatures")
    if s["transition_operators"]!=12:errors.append("operators")
    if s["paths"]!=25:errors.append("paths")
    data_dir=files("openbecoming84")
    # Synthetic checks independent of external package paths.
    z={"trace_id":"z","evidence_level":"S3","signals":{"repetitive_sameness":True,"difference_suppressed":True,"k_frozen":True,"value_source_opaque":True,"self_reinforcing_process":True,"resource_consumption_without_branching":True},"identity_fields":{}}
    if assess(z)["primary_signature"]!="Z_CLOSED":errors.append("zloop")
    h={"trace_id":"h","evidence_level":"S4","signals":{"closes_other_futures":True,"repeated_harm":True,"benefits_from_harm":True,"refuses_repair":True},"identity_fields":{}}
    if assess(h)["governance_state"]!="PATH_CONSEQUENCE_READY":errors.append("harm")
    bad={"trace_id":"bad","evidence_level":"S0","signals":{},"identity_fields":{},"person_name":"x"}
    if assess(bad).get("state")!="BLOCKED_IDENTITY_PRELOAD":errors.append("identity_guard")
    if any(k in assess(z) for k in ["total_score","aggregate_score","life_score","personhood_score"]):errors.append("score_leak")
    return {"passed":not errors,"errors":errors,"checks":7,"summary":s}
