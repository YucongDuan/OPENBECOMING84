from __future__ import annotations
import argparse, json
from pathlib import Path
from .core import *

def read_json(p): return json.loads(Path(p).read_text(encoding="utf-8"))
def emit(x): print(json.dumps(x,ensure_ascii=False,indent=2))

def main(argv=None):
    p=argparse.ArgumentParser(prog="openbecoming84")
    s=p.add_subparsers(dest="cmd",required=True)
    for n in ["summary","list-signatures","list-operators","charter","selftest"]:s.add_parser(n)
    x=s.add_parser("assess");x.add_argument("trace")
    x=s.add_parser("plan");x.add_argument("trace")
    x=s.add_parser("compare");x.add_argument("trace_a");x.add_argument("trace_b")
    x=s.add_parser("migrate-fusion");x.add_argument("profile")
    x=s.add_parser("init-ledger");x.add_argument("path");x.add_argument("trace_id")
    x=s.add_parser("append-ledger");x.add_argument("path");x.add_argument("event_type");x.add_argument("payload_json")
    x=s.add_parser("verify-ledger");x.add_argument("path")
    x=s.add_parser("capsule");x.add_argument("trace");x.add_argument("out_zip")
    a=p.parse_args(argv)
    if a.cmd=="summary":emit(summary())
    elif a.cmd=="list-signatures":emit(load_data("loop_signatures.json"))
    elif a.cmd=="list-operators":emit(load_data("operators.json"))
    elif a.cmd=="charter":emit(load_data("charter.json"))
    elif a.cmd=="assess":emit(assess(read_json(a.trace)))
    elif a.cmd=="plan":emit(transition_plan(read_json(a.trace)))
    elif a.cmd=="compare":emit(compare(read_json(a.trace_a),read_json(a.trace_b)))
    elif a.cmd=="migrate-fusion":emit(migrate_fusionloop(read_json(a.profile)))
    elif a.cmd=="init-ledger":emit(init_ledger(a.path,a.trace_id))
    elif a.cmd=="append-ledger":emit(append_ledger(a.path,a.event_type,json.loads(a.payload_json)))
    elif a.cmd=="verify-ledger":emit(verify_ledger(a.path))
    elif a.cmd=="capsule":emit(export_capsule(read_json(a.trace),a.out_zip))
    elif a.cmd=="selftest":
        r=selftest();emit(r);return 0 if r["passed"] else 1
    return 0
