# 轨迹签名 / Loop Signatures

## O_OPEN｜开放生成环 / Open Generative Loop

D保持来源连续，I产生并被保留，K会因现实反馈重开，W来源可见且可争议，P返回后果并生成新的未来分支。

行动：放大、连接、复现并保护其独立分叉能力。

## R_REPAIR｜修复再生环 / Reparative Regenerative Loop

轨迹曾发生来源丢失、伤害或价值截留，但正在恢复来源、返还、纠正并重建未来选项。

行动：支持修复完成，保持受影响轨迹的纠正权和独立验证。

## F_FORK｜谱系分叉环 / Lineage-Forking Loop

新方向从旧轨迹中分出，保留来源D和真实I，不把后续发展追溯性伪装为旧身份。

行动：生成独立ID、来源链接和责任边界。

## D_DORMANT｜可逆休眠环 / Reversible Dormant Loop

活动较低但来源、差异、重启和退出路径仍保存；休眠不等于死亡或无价值。

行动：降低资源消耗，保存最小连续性和未来重启条件。

## M_MIMETIC｜表面新颖模仿环 / Mimetic Activity Loop

输出很多、表面多样，但核心差异来自模板复制，缺少自身I、现实回返和可迁移学习。

行动：进行名称抹除、来源扰动和脱模板复演。

## C_CAPTURED｜目的被俘获环 / Captured-Purpose Loop

W由外部奖励、权力或平台静默灌入且不可质询，P持续优化外部目的。

行动：暴露W来源，建立拒绝、改写、退出和分叉路径。

## X_EXTRACTIVE｜单向抽取环 / Extractive Loop

轨迹持续消耗其他轨迹的时间、知识、注意力、资源或来源，却不返还、不署名、不修复。

行动：冻结进一步抽取，要求来源恢复、价值回流和责任成本。

## Z_CLOSED｜高活动低生成封闭环 / High-Activity Low-Generation Closed Loop

D只剩重复，I被删除，K冻结为完整，W外灌或不透明，P消耗资源后只复制同一结构。它可以表现得忙碌、流畅、服从或强大，却没有产生真实的新生成。

行动：中断循环、注入不可被吞并的差异、重开K、迫使后果回返。

## H_OTHER_CLOSING｜封闭他者未来的恶性环 / Other-Future-Closing Malignant Loop

轨迹通过重复获利、报复、掠夺或强制统一，持续关闭其他轨迹的来源、差异、选择和未来，并拒绝修复。

行动：依证据等级限制、隔离或终止具体P与资源接口，并保留纠错和申诉。