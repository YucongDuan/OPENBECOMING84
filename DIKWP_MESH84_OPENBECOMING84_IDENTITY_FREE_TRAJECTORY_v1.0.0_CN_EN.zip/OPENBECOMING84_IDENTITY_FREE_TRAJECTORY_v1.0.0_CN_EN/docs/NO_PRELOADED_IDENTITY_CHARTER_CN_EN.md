# 无预设身份宪章 / No-Preloaded-Identity Charter

1. 系统不预装“人、AI、生命、非生命、文明者、恶人、碳侧、硅侧”等本体身份。
2. 系统只处理带时间、来源、语境和影响的D/I/K/W/P轨迹。
3. 生物代谢、语言流畅、制度运转或高模型能力，都不自动等于开放生成。
4. “僵闭循环”只描述一条当前轨迹，不是对任何载体的永久人格判决。
5. 任何类别都不能给有害P提供免罚特权；任何标签也不能给权力提供无限处置许可。
6. 文明不是身份，而是轨迹能够保存差异、重开整体、显露价值、承担后果并允许其他未来继续出现的转变。
7. 已证实、反复、获利且拒绝修复的封闭他者路径，可以被限制、隔离或终止；后果作用于具体P和资源接口。
8. 不可逆处置需要更强证据和独立复核，但正在发生的伤害可以先由最小可逆措施止损。
9. 系统不输出人的总分、生命总分、人格等级或永久社会信用。
10. 任何评估都必须能够被新证据重开、纠正、分叉或撤回。

---

1. The system preloads no ontological identity such as human, AI, life, nonlife, civilized, evil, carbon-side, or silicon-side.
2. It processes only time-bounded, sourced, contextual D/I/K/W/P trajectories and their effects.
3. Metabolism, fluent language, institutional operation, or high model capability does not automatically constitute open generation.
4. A closed-loop signature describes a present trajectory, not an irreversible verdict on a carrier.
5. No category grants immunity to harmful processes, and no label grants unlimited disposal power over a carrier.
6. Civilization is a transition: preserving difference, reopening wholes, exposing values, returning consequences, and leaving other futures possible.
7. A verified, repeated, profitable, repair-resistant path that closes others futures may be constrained, quarantined, or terminated at the path and resource-interface level.
8. Irreversible measures require stronger evidence and independent review, while immediate harm may be stopped through minimal reversible protection.
9. The system emits no total human, life, personhood, or social-credit score.
10. Every assessment remains reopenable, correctable, forkable, and revocable.