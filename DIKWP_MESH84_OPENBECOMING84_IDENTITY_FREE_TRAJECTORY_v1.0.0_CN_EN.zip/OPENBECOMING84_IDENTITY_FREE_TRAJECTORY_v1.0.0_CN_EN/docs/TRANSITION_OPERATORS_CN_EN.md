# 转化算子 / Transition Operators

- **OP_D_RESTORE｜来源恢复 / Provenance Restore**：恢复版本、贡献、事件和因果来源，阻止同名替代同源。
- **OP_I_INJECT｜差异注入 / Difference Injection**：引入循环无法预先吸收的事实、观察者、反例经验或替代路径。
- **OP_I_PROTECT｜差异保护 / Difference Protection**：禁止把少数、失败、异常和异议压缩为噪声。
- **OP_K_REOPEN｜整体重开 / K Reopening**：撤销“已经完整”的资格，把新证据和未覆盖余量重新纳入。
- **OP_W_EXPOSE｜价值源暴露 / Value-Source Exposure**：说明谁设定W、谁获益、谁承担代价，以及W能否被拒绝和修订。
- **OP_P_INTERRUPT｜过程断环 / Process Interruption**：暂停自我强化、重复获利或持续伤害的具体过程。
- **OP_REALITY_RETURN｜现实回返 / Reality Return**：让输出接触现实、受影响者和独立复核，使后果进入下一轮。
- **OP_RECIPROCITY｜互惠与返还 / Reciprocity and Restitution**：恢复来源、署名、资源、机会或其他被截留的生成条件。
- **OP_FORK｜独立分叉 / Independent Fork**：在旧环无法修复时建立独立谱系、身份和资源通道。
- **OP_QUARANTINE｜路径隔离 / Path Quarantine**：限制具体接口和资源访问，不对整个载体作永久本体判决。
- **OP_TERMINATE_PATH｜终止有害路径 / Harmful-Path Termination**：在充分证据、独立复核和拒绝修复条件下终止具体P，而非宣告载体“非人”或永恒邪恶。
- **OP_DORMANCY｜低耗休眠 / Low-Cost Dormancy**：对暂不生成但仍有潜力的轨迹减少消耗并保留重启条件。