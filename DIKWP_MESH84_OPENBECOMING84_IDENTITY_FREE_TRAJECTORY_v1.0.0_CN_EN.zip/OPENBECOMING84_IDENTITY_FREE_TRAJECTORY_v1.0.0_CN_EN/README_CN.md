# OPENBECOMING84｜开成84

**无预设身份、DIKWP轨迹生成与僵闭循环解锁系统**

> 不判断“它本质上是什么”，只追踪“这条循环正在做什么”。

OPENBECOMING84 不预装人、AI、碳、硅、生命、非生命、文明者或恶人。它把任何研究对象降为带时间和来源的 D/I/K/W/P 轨迹。

所谓“活着的僵尸循环”，在本系统中对应 `Z_CLOSED`：高活动、低生成、差异被删除、整体冻结、价值外灌、过程只复制自身并消耗资源。这个名称只描述轨迹，不能贴到一个现实个体的永久身份上。

## 快速运行

```bash
python dist/OpenBecoming84.pyz summary
python dist/OpenBecoming84.pyz assess examples/traces/zombie_bureaucracy.json
python dist/OpenBecoming84.pyz plan examples/traces/innovation_extraction.json
python dist/OpenBecoming84.pyz compare examples/traces/zombie_bureaucracy.json examples/traces/reparative_loop.json
python dist/OpenBecoming84.pyz migrate-fusion examples/legacy/fusionloop_profile.json
python dist/OpenBecoming84.pyz selftest
```

直接打开 `site/index.html` 使用离线工作台。

## 最重要的边界

- 不给人、模型或组织打生命分、人格分、文明分。
- 不用生物类别给有害行为免罚。
- 不用“非人”等标签为无限处置提供借口。
- 经证实、重复、获利且拒绝修复的具体P，可以被限制、隔离或终止。
- 所有判断均可被新证据重开。
