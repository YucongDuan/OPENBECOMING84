# Contributing

Contributions must preserve the no-preloaded-identity rule, trace-level evidence, reopenability, and the prohibition on total personhood or life scores.
